import sys
from pathlib import Path
sys.path.insert(0,'/Users/hitesh/.codex/worktrees/shock-multiphase/athenak_nyu/tst/shocks-mc')
from common import edit_input, ROOT
changes = {'job/basename':'shock_turb_decay','mesh/nx1':32,'mesh/nx2':32,'mesh/nx3':32,'mesh/x2max':1,'mesh/x3max':1,'meshblock/nx1':32,'meshblock/nx2':32,'meshblock/nx3':32,'time/tlim':.2,'time/ndiag':100,'particles/random_seed':11,'tracer_seed_initial/count_per_event':4096,'tracer_seed_initial/region':'all','shock_tracking/lineage':'exploratory-decay-m3-32','shock_tracking/event_capacity':8192,'shock_tracking/trace':'false','output1/file_type':'hst','output1/dt':.01,'output2/dcycle':10,'output3/file_type':'bin','output3/variable':'hydro_u','output3/dt':.025,'initial_perturbations/variables':'velocity','initial_perturbations/velocity_rms':3,'initial_perturbations/remove_velocity_mean':'true','initial_perturbations/spectral_slope':2,'initial_perturbations/nlow':1,'initial_perturbations/nhigh':3,'initial_perturbations/f_solenoidal':.5,'initial_perturbations/rseed':24680,'initial_perturbations/localization':'none'}
for d in (1,2,3):
    changes[f'mesh/ix{d}_bc']='periodic'
    changes[f'mesh/ox{d}_bc']='periodic'
for side in ('l','r'):
    changes.update({'problem/d'+side:1,'problem/p'+side:1/1.4,'problem/u'+side:0})
# Remove planar-slice output settings: retain real whole-volume snapshots.
text = (ROOT/'inputs/tests/shock_mc.athinput').read_text()
text = '\n'.join(l for l in text.splitlines() if not l.startswith(('slice_x2','slice_x3')))+'\n'
text = edit_input(text, changes)
text = text.replace('# Experimental MC mass-flux tracer shock fixture; human scientific review pending.\n# Forward RH M=2, gamma1.4; downstream left, front x=.3+.5t.','# Exploratory decaying Mach3 Fourier box, no forcing/cooling.\n# Both shock_tube states are equal: uniform rho/P before existing Fourier velocity initializer.')
Path('/private/tmp/shock-turb-20261013/input.athinput').write_text(text)
