import sys, json, time, subprocess
from pathlib import Path
sys.path.insert(0,'/Users/hitesh/.codex/worktrees/shock-multiphase/athenak_nyu/tst/shocks-mc')
from common import edit_input, sha, provenance
root=Path('/private/tmp/shock-turb-20261013')
binary=Path('/Users/hitesh/.codex/worktrees/shock-multiphase/athenak_nyu/build-release/src/athena')
base=edit_input((root/'input.athinput').read_text(),{'output3/data_precision':'real'})
(root/'input.athinput').write_text(base)
report=provenance(binary);report['runs']=[]
for name,changes in [('baseline',{}),('off',{'shock_tracking/enabled':'false'}),('half_cfl',{'time/cfl_number':.15,'shock_tracking/lineage':'exploratory-decay-m3-32-cfl015'})]:
    directory=root/name;directory.mkdir()
    inp=directory/'input.athinput';inp.write_text(edit_input(base,changes))
    command=[str(binary),'-i',str(inp)];start=time.monotonic()
    with (directory/'run.log').open('w') as out:
        try:status=subprocess.run(command,cwd=directory,stdout=out,stderr=subprocess.STDOUT,timeout=180).returncode
        except subprocess.TimeoutExpired:status='timeout'
    row={'name':name,'command':command,'exit':status,'wall_seconds':time.monotonic()-start,'input_sha256':sha(inp),'log_sha256':sha(directory/'run.log')}
    report['runs'].append(row)
    (root/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if status!=0:raise RuntimeError(row)
